﻿Pitchside API — upload to ~/pitchside-api/

1. Extract ALL contents into the Python App root (pitchside-api).
2. Copy env.production.example to .env and fill Neon/Upstash/SECRET_KEY.
   Set MEDIA_LOCAL_DIR=/home/YOUR_USER/pitchside-api/media
3. Copy COPY-TO-API-DOCROOT.htaccess (or api.htaccess) to the api subdomain
   document root as .htaccess (may be a different folder).
4. In Terminal: activate venv from Setup Python App, then:
     cd ~/pitchside-api
     pip install -r requirements.txt
     alembic upgrade head
     chmod +x start-api.sh ensure-api.sh
     ./start-api.sh
5. Keep Setup Python App STOPPED. Use cron with ensure-api.sh.
