/* ODCC LIVE production runtime config: web on odcc.live, API on api.odcc.live.
   Edit these two values to repoint the app at a different API host; no rebuild
   is needed. Both must be absolute origins with no trailing slash. */
window.__PITCHSIDE_API_BASE_URL__ = "https://api.odcc.live";
window.__PITCHSIDE_STREAM_BASE_URL__ = "https://api.odcc.live";